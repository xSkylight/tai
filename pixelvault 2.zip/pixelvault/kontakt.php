<?php
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'Kontakt';

require __DIR__ . '/includes/header.php';
?>

<section class="page-banner page-banner--contact">
    <div class="page-banner__inner">
        <h1>Kontakt</h1>
        <p>Masz pytania? Napisz do nas!</p>
    </div>
</section>

<main class="wrap contact-layout">

    <!-- FORMULARZ -->
    <section class="contact-form-section">
        <div class="contact-card">
            <h2>Wyślij wiadomość</h2>
            <form id="contact-form">
                <label>Twoje imię</label>
                <input type="text" name="name" required placeholder="Jan Kowalski">

                <label>Adres e-mail</label>
                <input type="email" name="email" required placeholder="jan@example.com">

                <label>Temat</label>
                <select name="subject">
                    <option value="pytanie">Pytanie o produkt</option>
                    <option value="reklamacja">Reklamacja</option>
                    <option value="inne">Inne</option>
                </select>

                <label>Wiadomość</label>
                <textarea name="message" required placeholder="Napisz co Cię nurtuje..."></textarea>

                <button type="submit" class="btn btn--blue contact-submit">Wyślij wiadomość</button>
            </form>
            <div id="contact-msg" class="form-msg"></div>
        </div>
    </section>

    <!-- DANE KONTAKTOWE -->
    <aside class="contact-info">
        <div class="contact-card">
            <h2>Dane kontaktowe</h2>

            <div class="info-item">
                <div class="info-item__icon">📍</div>
                <div>
                    <strong>Adres</strong>
                    <p>ul. Gamingowa 7<br>00-001 Warszawa</p>
                </div>
            </div>

            <div class="info-item">
                <div class="info-item__icon">📞</div>
                <div>
                    <strong>Telefon</strong>
                    <p>+48 500 123 456</p>
                    <small>Pon–Pt: 9:00–17:00</small>
                </div>
            </div>

            <div class="info-item">
                <div class="info-item__icon">✉️</div>
                <div>
                    <strong>E-mail</strong>
                    <p>kontakt@pixelvault.pl</p>
                    <small>Odpowiadamy w ciągu 24h</small>
                </div>
            </div>

            <div class="info-item">
                <div class="info-item__icon">🕐</div>
                <div>
                    <strong>Godziny pracy</strong>
                    <p>Poniedziałek – Piątek<br>9:00 – 17:00</p>
                </div>
            </div>
        </div>
    </aside>

</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
