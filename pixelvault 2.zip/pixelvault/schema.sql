CREATE DATABASE IF NOT EXISTS pixelvault CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pixelvault;

CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS platforms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(8,2) NOT NULL,
    image VARCHAR(200) NOT NULL,
    category_id INT NOT NULL,
    platform_id INT NOT NULL,
    active TINYINT DEFAULT 1,
    FOREIGN KEY (category_id) REFERENCES categories(id),
    FOREIGN KEY (platform_id) REFERENCES platforms(id)
);

CREATE TABLE IF NOT EXISTS newsletter (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(150) NOT NULL UNIQUE,
    created_at DATETIME NOT NULL
);

-- Dane testowe
INSERT INTO categories (name) VALUES ('RPG'), ('Akcja'), ('Wyścigi'), ('Sportowe'), ('Sci-Fi');

INSERT INTO platforms (name) VALUES ('PC'), ('PS5'), ('Xbox Series X');

INSERT INTO products (title, description, price, image, category_id, platform_id) VALUES
('Cyber Quest',       'Cyberpunkowe RPG w mrocznym mieście przyszłości.',     129.00, 'cyber-quest.png',      1, 1),
('Racing X',          'Dynamiczne wyścigi futurystycznych samochodów.',         119.00, 'racing-x.png',         3, 2),
('Battle Arena',      'Taktyczna strzelanka osadzona w świecie po wojnie.',     139.00, 'battle-arena.png',     2, 3),
('Mystic World',      'Epicka przygoda fantasy z otwartym światem.',            109.00, 'mystic-world.png',     1, 1),
('Space Ops',         'Kosmiczna gra akcji z bitwami statków.',                 129.00, 'space-ops.png',        5, 2),
('Football Stars',    'Symulator piłki nożnej dla fanów sportu.',               99.00,  'football-stars.png',   4, 3),
('Shadow Realm',      'Mroczne RPG akcji w świecie cieni i ruin.',              119.00, 'shadow-realm.png',     1, 1),
('Legends of Valor',  'Przygodowa gra fantasy z bohaterami i zamkami.',         139.00, 'legends-of-valor.png', 1, 2),
('Neon Drift',        'Arcade racing w neonowym mieście przyszłości.',          89.00,  'neon-drift.png',       3, 1);
