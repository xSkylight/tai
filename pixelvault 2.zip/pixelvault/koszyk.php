<?php
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'Koszyk';

$cartItems = getCartItems();
$total = cartTotal();

require __DIR__ . '/includes/header.php';
?>

<section class="page-banner page-banner--purple">
    <div class="page-banner__inner">
        <h1>Twój koszyk</h1>
        <p>Sprawdź zawartość i złóż zamówienie</p>
    </div>
</section>

<main class="wrap cart-layout">

    <!-- LISTA PRODUKTÓW W KOSZYKU -->
    <section class="cart-items-section">
        <h2 class="section-title">Produkty w koszyku</h2>

        <?php if (empty($cartItems)): ?>
            <div class="empty-cart">
                <p>Twój koszyk jest pusty.</p>
                <a href="/pixelvault/sklep.php" class="btn btn--blue">Przejdź do sklepu</a>
            </div>
        <?php else: ?>
            <div class="cart-table-header">
                <span>Produkt</span>
                <span>Cena</span>
                <span>Ilość</span>
                <span>Suma</span>
                <span></span>
            </div>

            <div id="cart-rows">
            <?php foreach ($cartItems as $item): ?>
            <div class="cart-row" data-id="<?= $item['id'] ?>">
                <div class="cart-row__product">
                    <img src="/pixelvault/images/<?= h($item['image']) ?>" alt="<?= h($item['title']) ?>">
                    <div>
                        <strong><?= h($item['title']) ?></strong>
                        <small><?= h($item['platform']) ?> · <?= h($item['category']) ?></small>
                    </div>
                </div>
                <div class="cart-row__price"><?= price($item['price']) ?></div>
                <div class="cart-row__qty">
                    <button class="qty-btn" data-action="minus">−</button>
                    <span class="qty-val"><?= $item['qty'] ?></span>
                    <button class="qty-btn" data-action="plus">+</button>
                </div>
                <div class="cart-row__sum"><?= price($item['subtotal']) ?></div>
                <div class="cart-row__remove">
                    <button class="remove-btn" title="Usuń">✕</button>
                </div>
            </div>
            <?php endforeach; ?>
            </div>

            <div class="cart-actions">
                <button id="clear-cart" class="btn btn--outline">Wyczyść koszyk</button>
                <a href="/pixelvault/sklep.php" class="btn btn--outline">← Kontynuuj zakupy</a>
            </div>
        <?php endif; ?>
    </section>

    <!-- PODSUMOWANIE I FORMULARZ ZAMÓWIENIA -->
    <?php if (!empty($cartItems)): ?>
    <aside class="cart-summary">
        <div class="summary-box">
            <h3>Podsumowanie</h3>
            <div class="summary-row">
                <span>Produkty:</span>
                <strong id="summary-total"><?= price($total) ?></strong>
            </div>
            <div class="summary-row">
                <span>Dostawa:</span>
                <strong class="free">GRATIS</strong>
            </div>
            <div class="summary-row summary-row--big">
                <span>Do zapłaty:</span>
                <strong id="summary-grand"><?= price($total) ?></strong>
            </div>
        </div>

        <div class="order-box">
            <h3>Dane do zamówienia</h3>
            <form id="order-form">
                <label>Imię i nazwisko</label>
                <input type="text" name="name" required placeholder="Jan Kowalski">

                <label>Adres e-mail</label>
                <input type="email" name="email" required placeholder="jan@example.com">

                <label>Telefon</label>
                <input type="text" name="phone" required placeholder="600 000 000">

                <label>Adres dostawy</label>
                <textarea name="address" required placeholder="ul. Przykładowa 1, 00-000 Warszawa"></textarea>

                <label>Metoda płatności</label>
                <select name="payment">
                    <option value="blik">BLIK</option>
                    <option value="karta">Karta płatnicza</option>
                    <option value="przelew">Przelew bankowy</option>
                </select>

                <button type="submit" class="btn btn--purple order-submit-btn">
                    Złóż zamówienie
                </button>
            </form>
            <div id="order-msg" class="form-msg"></div>
        </div>
    </aside>
    <?php endif; ?>

</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
