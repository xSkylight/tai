<?php
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'Sklep';

$filters = [
    'category_id' => $_GET['cat'] ?? '',
    'platform_id' => $_GET['plat'] ?? '',
    'search' => $_GET['q'] ?? '',
    'sort' => $_GET['sort'] ?? 'id',
];

$categories = getCategories();
$platforms = getPlatforms();
$products = getAllProducts($filters);

require __DIR__ . '/includes/header.php';
?>

<section class="page-banner">
    <div class="page-banner__inner">
        <h1>Sklep z grami</h1>
        <p>Znajdź swoją następną ulubioną grę</p>
    </div>
</section>

<main class="wrap shop-layout">
    <!-- Sidebar filtrów -->
    <aside class="sidebar">
        <div class="sidebar__box">
            <h3 class="sidebar__title">🎮 Filtruj gry</h3>
            <form method="get" action="/pixelvault/sklep.php" class="filter-form">
                <label>Kategoria</label>
                <select name="cat">
                    <option value="">Wszystkie kategorie</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" <?= ($filters['category_id'] == $cat['id']) ? 'selected' : '' ?>><?= h($cat['name']) ?></option>
                    <?php endforeach; ?>
                </select>

                <label>Platforma</label>
                <select name="plat">
                    <option value="">Wszystkie platformy</option>
                    <?php foreach ($platforms as $pl): ?>
                        <option value="<?= $pl['id'] ?>" <?= ($filters['platform_id'] == $pl['id']) ? 'selected' : '' ?>><?= h($pl['name']) ?></option>
                    <?php endforeach; ?>
                </select>

                <label>Sortuj według</label>
                <select name="sort">
                    <option value="id" <?= $filters['sort'] === 'id' ? 'selected' : '' ?>>Domyślne</option>
                    <option value="price_asc" <?= $filters['sort'] === 'price_asc' ? 'selected' : '' ?>>Cena rosnąco</option>
                    <option value="price_desc" <?= $filters['sort'] === 'price_desc' ? 'selected' : '' ?>>Cena malejąco</option>
                    <option value="name" <?= $filters['sort'] === 'name' ? 'selected' : '' ?>>Nazwa A-Z</option>
                </select>

                <label>Wyszukaj</label>
                <div class="search-wrap">
                    <input type="text" name="q" value="<?= h($filters['search']) ?>" placeholder="np. Cyber Quest...">
                </div>

                <button type="submit" class="btn btn--blue filter-btn">Szukaj</button>
                <a href="/pixelvault/sklep.php" class="reset-link">Resetuj filtry</a>
            </form>
        </div>
    </aside>

    <!-- Lista produktów -->
    <section class="content-area">
        <div class="section-header">
            <h2>Wszystkie gry</h2>
            <span class="products-count">Znaleziono: <strong><?= count($products) ?></strong></span>
        </div>

        <?php if (empty($products)): ?>
            <div class="no-results">
                <p>Nie znaleziono żadnych gier dla podanych kryteriów.</p>
                <a href="/pixelvault/sklep.php" class="btn btn--blue">Pokaż wszystkie</a>
            </div>
        <?php else: ?>
        <div class="products-grid">
            <?php foreach ($products as $p): ?>
            <div class="product-card">
                <div class="product-card__img-wrap">
                    <img src="/pixelvault/images/<?= h($p['image']) ?>" alt="<?= h($p['title']) ?>">
                    <span class="product-card__platform-badge"><?= h($p['platform']) ?></span>
                </div>
                <div class="product-card__body">
                    <h4 class="product-card__title"><?= h($p['title']) ?></h4>
                    <span class="product-card__genre"><?= h($p['category']) ?></span>
                    <p class="product-card__desc"><?= h(mb_substr($p['description'], 0, 60)) ?>...</p>
                    <div class="product-card__footer">
                        <span class="product-card__price"><?= price($p['price']) ?></span>
                        <button class="btn btn--blue btn-sm add-to-cart" data-id="<?= $p['id'] ?>">Dodaj do koszyka</button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </section>
</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
