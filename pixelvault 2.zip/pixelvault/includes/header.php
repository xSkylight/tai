<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($pageTitle ?? 'PixelVault') ?> – PixelVault</title>
    <link rel="stylesheet" href="/pixelvault/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@500;600;700&family=Open+Sans:wght@400;600;700&display=swap" rel="stylesheet">
</head>
<body class="page-<?= h(currentPage()) ?>">

<header class="topbar">
    <div class="topbar__inner wrap">
        <a href="/pixelvault/index.php" class="topbar__logo">
            <img src="/pixelvault/images/logo.png" alt="PixelVault logo" class="topbar__logo-img">
        </a>

        <nav class="topbar__nav">
            <a href="/pixelvault/index.php" class="nav-item <?= currentPage() === 'index' ? 'nav-item--active' : '' ?>">Strona główna</a>
            <a href="/pixelvault/sklep.php" class="nav-item <?= currentPage() === 'sklep' ? 'nav-item--active' : '' ?>">Sklep</a>
            <a href="/pixelvault/koszyk.php" class="nav-item <?= currentPage() === 'koszyk' ? 'nav-item--active' : '' ?>">Koszyk</a>
            <a href="/pixelvault/kontakt.php" class="nav-item <?= currentPage() === 'kontakt' ? 'nav-item--active' : '' ?>">Kontakt</a>
        </nav>

        <a href="/pixelvault/koszyk.php" class="cart-btn">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
            <span id="cart-count"><?= cartCount() ?></span>
        </a>
    </div>
</header>
