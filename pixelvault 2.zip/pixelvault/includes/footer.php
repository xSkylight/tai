
<footer class="footer">
    <div class="wrap footer__inner">
        <div class="footer__brand">
            <img src="/pixelvault/images/logo.png" alt="PixelVault" class="footer__logo">
            <p>Najlepsze gry w jednym miejscu.<br>Szybka dostawa, uczciwe ceny.</p>
        </div>
        <div class="footer__links">
            <strong>Nawigacja</strong>
            <a href="/pixelvault/index.php">Strona główna</a>
            <a href="/pixelvault/sklep.php">Sklep</a>
            <a href="/pixelvault/koszyk.php">Koszyk</a>
            <a href="/pixelvault/kontakt.php">Kontakt</a>
        </div>
        <div class="footer__newsletter">
            <strong>Newsletter</strong>
            <p>Bądź na bieżąco z nowościami i promocjami!</p>
            <form id="newsletter-form" class="footer__nl-form">
                <input type="email" name="email" placeholder="Twój adres e-mail" required>
                <button type="submit" class="btn btn--purple">Zapisz się</button>
            </form>
            <p id="nl-msg" class="nl-msg"></p>
        </div>
    </div>
    <div class="footer__bottom wrap">
        <span>&copy; <?= date('Y') ?> PixelVault – Sklep z grami</span>
    </div>
</footer>

<div id="toast" class="toast"></div>

<script src="/pixelvault/app.js"></script>
</body>
</html>
