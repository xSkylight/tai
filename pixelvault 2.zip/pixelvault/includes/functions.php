<?php
session_start();

require_once __DIR__ . '/db.php';

// --- PRODUKTY ---

function getAllProducts(array $filters = []): array {
    $db = getDB();

    $sql = "SELECT p.*, c.name AS category, pl.name AS platform
            FROM products p
            JOIN categories c ON p.category_id = c.id
            JOIN platforms pl ON p.platform_id = pl.id
            WHERE p.active = 1";

    $params = [];

    if (!empty($filters['category_id'])) {
        $sql .= " AND p.category_id = :cat";
        $params['cat'] = $filters['category_id'];
    }
    if (!empty($filters['platform_id'])) {
        $sql .= " AND p.platform_id = :plat";
        $params['plat'] = $filters['platform_id'];
    }
    if (!empty($filters['search'])) {
        $sql .= " AND p.title LIKE :search";
        $params['search'] = '%' . $filters['search'] . '%';
    }

    $sort = $filters['sort'] ?? 'id';
    if ($sort === 'price_asc') $sql .= " ORDER BY p.price ASC";
    elseif ($sort === 'price_desc') $sql .= " ORDER BY p.price DESC";
    elseif ($sort === 'name') $sql .= " ORDER BY p.title ASC";
    else $sql .= " ORDER BY p.id ASC";

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getCategories(): array {
    return getDB()->query("SELECT * FROM categories ORDER BY name")->fetchAll();
}

function getPlatforms(): array {
    return getDB()->query("SELECT * FROM platforms ORDER BY name")->fetchAll();
}

// --- KOSZYK (SESSION) ---

function getCart(): array {
    return $_SESSION['cart'] ?? [];
}

function addToCart(int $id): void {
    if (!isset($_SESSION['cart'][$id])) {
        $_SESSION['cart'][$id] = 0;
    }
    $_SESSION['cart'][$id]++;
}

function removeFromCart(int $id): void {
    unset($_SESSION['cart'][$id]);
}

function changeQty(int $id, int $delta): void {
    $current = $_SESSION['cart'][$id] ?? 0;
    $new = $current + $delta;
    if ($new <= 0) {
        unset($_SESSION['cart'][$id]);
    } else {
        $_SESSION['cart'][$id] = $new;
    }
}

function clearCart(): void {
    $_SESSION['cart'] = [];
}

function getCartItems(): array {
    $cart = getCart();
    if (empty($cart)) return [];

    $ids = implode(',', array_map('intval', array_keys($cart)));
    $rows = getDB()->query("SELECT p.*, c.name AS category, pl.name AS platform
        FROM products p
        JOIN categories c ON p.category_id = c.id
        JOIN platforms pl ON p.platform_id = pl.id
        WHERE p.id IN ($ids)")->fetchAll();

    $result = [];
    foreach ($rows as $row) {
        $qty = $cart[$row['id']] ?? 1;
        $row['qty'] = $qty;
        $row['subtotal'] = $qty * $row['price'];
        $result[] = $row;
    }
    return $result;
}

function cartCount(): int {
    return array_sum(getCart());
}

function cartTotal(): float {
    $total = 0;
    foreach (getCartItems() as $item) {
        $total += $item['subtotal'];
    }
    return $total;
}

// --- HELPER ---

function price(float $p): string {
    return number_format($p, 2, ',', ' ') . ' zł';
}

function h(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES);
}

function currentPage(): string {
    $file = basename($_SERVER['PHP_SELF'], '.php');
    return $file;
}
