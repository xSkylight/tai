// PixelVault – app.js

const BASE = '/pixelvault';

// Toast
let toastTimeout;
function showToast(msg) {
    const t = document.getElementById('toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('toast--show');
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => t.classList.remove('toast--show'), 2500);
}

// Zaktualizuj licznik koszyka w topbarze
function updateCartCount(n) {
    const el = document.getElementById('cart-count');
    if (el) el.textContent = n;
}

// Wyślij POST do API
async function apiPost(url, data) {
    const body = new URLSearchParams(data);
    const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body
    });
    return res.json();
}

// --- DODAJ DO KOSZYKA ---
document.addEventListener('click', async (e) => {
    const btn = e.target.closest('.add-to-cart');
    if (!btn) return;

    const id = btn.dataset.id;
    if (!id) return;

    btn.disabled = true;
    try {
        const data = await apiPost(`${BASE}/api/cart.php`, { action: 'add', id });
        if (data.ok) {
            updateCartCount(data.count);
            showToast('✓ Dodano do koszyka!');
        }
    } catch (err) {
        showToast('Błąd połączenia.');
    } finally {
        btn.disabled = false;
    }
});

// --- KOSZYK – zmiana ilości i usuwanie ---
const cartRows = document.getElementById('cart-rows');
if (cartRows) {
    cartRows.addEventListener('click', async (e) => {
        const row = e.target.closest('.cart-row');
        if (!row) return;
        const id = row.dataset.id;

        // przycisk ilości
        const qtyBtn = e.target.closest('.qty-btn');
        if (qtyBtn) {
            const action = qtyBtn.dataset.action === 'plus' ? 'plus' : 'minus';
            const data = await apiPost(`${BASE}/api/cart.php`, { action, id });
            updateCartCount(data.count);

            const qtyEl = row.querySelector('.qty-val');
            const currentQty = parseInt(qtyEl.textContent);
            const newQty = action === 'plus' ? currentQty + 1 : currentQty - 1;

            if (newQty <= 0) {
                row.remove();
                refreshSummary(data.total);
                showToast('Usunięto z koszyka');
            } else {
                qtyEl.textContent = newQty;
                // przelicz sumę wiersza
                const unitPrice = parseFloat(row.querySelector('.cart-row__price').dataset.price || 0);
                // aktualizuj wyświetlaną sumę (uproszczone)
                refreshSummary(data.total);
            }
            return;
        }

        // przycisk usuń
        const removeBtn = e.target.closest('.remove-btn');
        if (removeBtn) {
            const data = await apiPost(`${BASE}/api/cart.php`, { action: 'remove', id });
            updateCartCount(data.count);
            row.style.opacity = '0.4';
            setTimeout(() => row.remove(), 200);
            refreshSummary(data.total);
            showToast('Usunięto z koszyka');
        }
    });
}

// Wyczyść koszyk
const clearBtn = document.getElementById('clear-cart');
if (clearBtn) {
    clearBtn.addEventListener('click', async () => {
        if (!confirm('Wyczyścić cały koszyk?')) return;
        const data = await apiPost(`${BASE}/api/cart.php`, { action: 'clear' });
        updateCartCount(0);
        if (cartRows) cartRows.innerHTML = '<p style="color: var(--text2); padding: 20px 0;">Koszyk jest pusty.</p>';
        refreshSummary('0,00 zł');
        showToast('Koszyk wyczyszczony');
    });
}

function refreshSummary(total) {
    const els = document.querySelectorAll('#summary-total, #summary-grand');
    els.forEach(el => { if (el) el.textContent = total; });
}

// --- FORMULARZ ZAMÓWIENIA ---
const orderForm = document.getElementById('order-form');
if (orderForm) {
    orderForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const msgEl = document.getElementById('order-msg');
        const btn = orderForm.querySelector('button[type="submit"]');
        btn.disabled = true;
        btn.textContent = 'Wysyłam...';

        const data = await apiPost(`${BASE}/api/order.php`, Object.fromEntries(new FormData(orderForm)));

        if (data.ok) {
            msgEl.style.color = '#4caf7d';
            msgEl.textContent = data.msg;
            orderForm.reset();
            updateCartCount(0);
            if (cartRows) cartRows.innerHTML = '<p style="color: var(--text2); padding: 20px 0;">Koszyk jest pusty.</p>';
            showToast('✓ Zamówienie złożone!');
        } else {
            msgEl.style.color = '#e55';
            msgEl.textContent = data.msg || 'Wystąpił błąd.';
            btn.disabled = false;
            btn.textContent = 'Złóż zamówienie';
        }
    });
}

// --- FORMULARZ KONTAKTOWY ---
const contactForm = document.getElementById('contact-form');
if (contactForm) {
    contactForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const msgEl = document.getElementById('contact-msg');

        const data = await apiPost(`${BASE}/api/contact.php`, Object.fromEntries(new FormData(contactForm)));

        if (data.ok) {
            msgEl.style.color = '#4caf7d';
            msgEl.textContent = data.msg;
            contactForm.reset();
            showToast('✓ Wiadomość wysłana!');
        } else {
            msgEl.style.color = '#e55';
            msgEl.textContent = data.msg || 'Błąd wysyłania.';
        }
    });
}

// --- NEWSLETTER ---
const nlForm = document.getElementById('newsletter-form');
if (nlForm) {
    nlForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const msgEl = document.getElementById('nl-msg');

        const data = await apiPost(`${BASE}/api/newsletter.php`, Object.fromEntries(new FormData(nlForm)));

        if (data.ok) {
            msgEl.style.color = '#4caf7d';
            msgEl.textContent = data.msg;
            nlForm.reset();
        } else {
            msgEl.style.color = '#e55';
            msgEl.textContent = data.msg;
        }
    });
}
