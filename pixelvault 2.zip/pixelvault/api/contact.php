<?php
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false]);
    exit;
}

$name    = trim($_POST['name'] ?? '');
$email   = trim($_POST['email'] ?? '');
$subject = trim($_POST['subject'] ?? '');
$message = trim($_POST['message'] ?? '');

if (!$name || !$email || !$message) {
    echo json_encode(['ok' => false, 'msg' => 'Wypełnij wszystkie pola.']);
    exit;
}

$text = "=== Nowa wiadomość ===\n";
$text .= "Data: " . date('Y-m-d H:i:s') . "\n";
$text .= "Imię: $name\n";
$text .= "E-mail: $email\n";
$text .= "Temat: $subject\n";
$text .= "Treść:\n$message\n";
$text .= "=====================\n\n";

$file = __DIR__ . '/../contacts/kontakt_' . date('Ymd_His') . '_' . rand(100,999) . '.txt';
file_put_contents($file, $text);

echo json_encode(['ok' => true, 'msg' => 'Wiadomość wysłana! Odpowiemy wkrótce.']);
