<?php
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

$action = $_POST['action'] ?? '';
$id = (int)($_POST['id'] ?? 0);

switch ($action) {
    case 'add':
        if ($id > 0) addToCart($id);
        break;
    case 'remove':
        if ($id > 0) removeFromCart($id);
        break;
    case 'plus':
        if ($id > 0) changeQty($id, 1);
        break;
    case 'minus':
        if ($id > 0) changeQty($id, -1);
        break;
    case 'clear':
        clearCart();
        break;
}

echo json_encode([
    'ok' => true,
    'count' => cartCount(),
    'total' => price(cartTotal()),
    'total_raw' => cartTotal(),
]);
