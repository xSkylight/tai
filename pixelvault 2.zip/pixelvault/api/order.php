<?php
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'msg' => 'Zła metoda']);
    exit;
}

$name    = trim($_POST['name'] ?? '');
$email   = trim($_POST['email'] ?? '');
$phone   = trim($_POST['phone'] ?? '');
$address = trim($_POST['address'] ?? '');
$payment = trim($_POST['payment'] ?? '');

if (!$name || !$email || !$phone || !$address) {
    echo json_encode(['ok' => false, 'msg' => 'Uzupełnij wszystkie pola.']);
    exit;
}

$items = getCartItems();
if (empty($items)) {
    echo json_encode(['ok' => false, 'msg' => 'Koszyk jest pusty.']);
    exit;
}

$order = [
    'id' => uniqid('ORD-'),
    'date' => date('Y-m-d H:i:s'),
    'customer' => [
        'name' => $name,
        'email' => $email,
        'phone' => $phone,
        'address' => $address,
        'payment' => $payment,
    ],
    'items' => array_map(function($item) {
        return [
            'id' => $item['id'],
            'title' => $item['title'],
            'qty' => $item['qty'],
            'price' => $item['price'],
            'subtotal' => $item['subtotal'],
        ];
    }, $items),
    'total' => cartTotal(),
];

$file = __DIR__ . '/../orders/order_' . $order['id'] . '.json';
file_put_contents($file, json_encode($order, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

clearCart();

echo json_encode(['ok' => true, 'msg' => 'Zamówienie złożone! Dziękujemy, ' . htmlspecialchars($name) . '.']);
