<?php
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

$email = trim($_POST['email'] ?? '');

if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['ok' => false, 'msg' => 'Podaj poprawny adres e-mail.']);
    exit;
}

try {
    $db = getDB();
    // sprawdź czy już istnieje
    $check = $db->prepare("SELECT id FROM newsletter WHERE email = ?");
    $check->execute([$email]);
    if ($check->fetch()) {
        echo json_encode(['ok' => false, 'msg' => 'Ten e-mail jest już zapisany.']);
        exit;
    }
    $db->prepare("INSERT INTO newsletter (email, created_at) VALUES (?, NOW())")->execute([$email]);
    echo json_encode(['ok' => true, 'msg' => 'Zapisano do newslettera!']);
} catch (Exception $e) {
    echo json_encode(['ok' => false, 'msg' => 'Błąd zapisu. Spróbuj ponownie.']);
}
