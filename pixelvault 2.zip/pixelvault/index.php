<?php
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'Strona główna';

$filters = [
    'category_id' => $_GET['cat'] ?? '',
    'platform_id' => $_GET['plat'] ?? '',
    'search' => $_GET['q'] ?? '',
    'sort' => $_GET['sort'] ?? 'id',
];

$categories = getCategories();
$platforms = getPlatforms();
$products = array_slice(getAllProducts($filters), 0, 6);
$cartItems = getCartItems();

require __DIR__ . '/includes/header.php';
?>

<section class="hero hero--home">
    <div class="hero__overlay">
        <h1 class="hero__title">Witaj w <span>PixelVault</span></h1>
        <p class="hero__sub">Odkryj setki gier w najlepszych cenach</p>
        <a href="/pixelvault/sklep.php" class="btn btn--blue">Przejdź do sklepu</a>
    </div>
</section>

<main class="wrap main-layout">
    <!-- SIDEBAR z filtrami -->
    <aside class="sidebar">
        <div class="sidebar__box">
            <h3 class="sidebar__title">Filtry</h3>
            <form method="get" action="/pixelvault/index.php" class="filter-form">
                <label>Kategoria</label>
                <select name="cat">
                    <option value="">Wszystkie</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" <?= ($filters['category_id'] == $cat['id']) ? 'selected' : '' ?>><?= h($cat['name']) ?></option>
                    <?php endforeach; ?>
                </select>

                <label>Platforma</label>
                <select name="plat">
                    <option value="">Wszystkie</option>
                    <?php foreach ($platforms as $pl): ?>
                        <option value="<?= $pl['id'] ?>" <?= ($filters['platform_id'] == $pl['id']) ? 'selected' : '' ?>><?= h($pl['name']) ?></option>
                    <?php endforeach; ?>
                </select>

                <label>Sortowanie</label>
                <select name="sort">
                    <option value="id" <?= $filters['sort'] === 'id' ? 'selected' : '' ?>>Domyślne</option>
                    <option value="price_asc" <?= $filters['sort'] === 'price_asc' ? 'selected' : '' ?>>Cena: rosnąco</option>
                    <option value="price_desc" <?= $filters['sort'] === 'price_desc' ? 'selected' : '' ?>>Cena: malejąco</option>
                    <option value="name" <?= $filters['sort'] === 'name' ? 'selected' : '' ?>>Nazwa A-Z</option>
                </select>

                <label>Szukaj</label>
                <input type="text" name="q" value="<?= h($filters['search']) ?>" placeholder="Wpisz nazwę gry...">

                <button type="submit" class="btn btn--blue filter-btn">Filtruj</button>
            </form>
        </div>
    </aside>

    <!-- PRODUKTY -->
    <section class="content-area">
        <div class="section-header">
            <h2>Polecane gry</h2>
            <a href="/pixelvault/sklep.php" class="see-all">Zobacz wszystkie →</a>
        </div>

        <div class="products-grid">
            <?php foreach ($products as $p): ?>
            <div class="product-card">
                <div class="product-card__img-wrap">
                    <img src="/pixelvault/images/<?= h($p['image']) ?>" alt="<?= h($p['title']) ?>">
                    <span class="product-card__platform-badge"><?= h($p['platform']) ?></span>
                </div>
                <div class="product-card__body">
                    <h4 class="product-card__title"><?= h($p['title']) ?></h4>
                    <span class="product-card__genre"><?= h($p['category']) ?></span>
                    <div class="product-card__footer">
                        <span class="product-card__price"><?= price($p['price']) ?></span>
                        <button class="btn btn--blue btn-sm add-to-cart" data-id="<?= $p['id'] ?>">+ Koszyk</button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- podgląd koszyka -->
        <div class="cart-preview-box">
            <h3>🛒 Twój koszyk</h3>
            <?php if (empty($cartItems)): ?>
                <p class="empty-msg">Koszyk jest pusty. Dodaj swoje pierwsze gry!</p>
            <?php else: ?>
                <table class="cart-mini-table">
                    <thead>
                        <tr><th>Gra</th><th>Ilość</th><th>Cena</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cartItems as $item): ?>
                        <tr>
                            <td><?= h($item['title']) ?></td>
                            <td><?= $item['qty'] ?></td>
                            <td><?= price($item['subtotal']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="cart-preview-total">
                    Razem: <strong><?= price(cartTotal()) ?></strong>
                </div>
                <a href="/pixelvault/koszyk.php" class="btn btn--purple">Przejdź do koszyka</a>
            <?php endif; ?>
        </div>
    </section>
</main>

<?php require __DIR__ . '/includes/footer.php'; ?>
